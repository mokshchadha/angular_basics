import { Component } from '@angular/core';

@Component({
  selector: 'app-successwarning',
  templateUrl: './successwarning.component.html',
  styleUrl: './successwarning.component.css'
})
export class SuccesswarningComponent {

}
