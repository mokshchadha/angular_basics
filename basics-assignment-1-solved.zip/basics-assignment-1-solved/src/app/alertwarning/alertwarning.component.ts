import { Component } from '@angular/core';

@Component({
  selector: 'app-alertwarning',
  templateUrl: './alertwarning.component.html',
  styleUrl: './alertwarning.component.css'
})
export class AlertwarningComponent {

}
